# ==========================================
# AI Dyscalculia Support System
# Model Training Script
# ==========================================

import pandas as pd
import pickle
import os

from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score


# -----------------------------
# Load dataset
# -----------------------------

data = pd.read_csv("cleaned_learner_data.csv")


# -----------------------------
# Keep Dyscalculia learners only
# -----------------------------

data = data[
    data["neurodivergence_type"] == "Dyscalculia"
].copy()


# -----------------------------
# Remove missing values
# -----------------------------

columns_needed = [
    "age_group",
    "education_level",
    "primary_challenge",
    "prior_elearning_experience",
    "font_type",
    "font_size_pt",
    "color_theme",
    "layout_mode",
    "content_format"
]

data = data.dropna(subset=columns_needed)


# -----------------------------
# Input Features
# -----------------------------

features = [

    "age_group",

    "education_level",

    "primary_challenge",

    "prior_elearning_experience"

]


# -----------------------------
# AI Prediction Targets
# -----------------------------

targets = {

    "content_model":"content_format",

    "font_model":"font_type",

    "theme_model":"color_theme",

    "layout_model":"layout_mode",

    "fontsize_model":"font_size_pt"

}


# -----------------------------
# Encode input features
# -----------------------------

feature_encoders = {}

encoded_data = data.copy()

for feature in features:

    encoder = LabelEncoder()

    encoded_data[feature] = encoder.fit_transform(
        encoded_data[feature].astype(str)
    )

    feature_encoders[feature] = encoder


X = encoded_data[features]


# -----------------------------
# Create Models folder
# -----------------------------

os.makedirs("models", exist_ok=True)


# -----------------------------
# Train each AI model
# -----------------------------

target_encoders = {}

results = []

for model_name, target in targets.items():

    y_encoder = LabelEncoder()

    y = y_encoder.fit_transform(
        encoded_data[target].astype(str)
    )

    target_encoders[target] = y_encoder


    X_train, X_test, y_train, y_test = train_test_split(

        X,

        y,

        test_size=0.2,

        random_state=42

    )


    model = RandomForestClassifier(

        n_estimators=100,

        random_state=42

    )


    model.fit(

        X_train,

        y_train

    )


    predictions = model.predict(

        X_test

    )


    accuracy = accuracy_score(

        y_test,

        predictions

    )


    results.append(

        {

            "Model":model_name,

            "Target":target,

            "Accuracy":round(accuracy*100,2)

        }

    )


    with open(

        f"models/{model_name}.pkl",

        "wb"

    ) as file:

        pickle.dump(

            model,

            file

        )


# -----------------------------
# Save encoders
# -----------------------------

with open(

    "models/feature_encoders.pkl",

    "wb"

) as file:

    pickle.dump(

        feature_encoders,

        file

    )


with open(

    "models/target_encoders.pkl",

    "wb"

) as file:

    pickle.dump(

        target_encoders,

        file

    )


# -----------------------------
# Display Results
# -----------------------------

results = pd.DataFrame(results)

print("\n==============================")
print("MODEL TRAINING COMPLETE")
print("==============================\n")

print(results)

print("\nModels saved inside /models folder.")