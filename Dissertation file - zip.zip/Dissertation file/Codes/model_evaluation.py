# ==========================================
# AI Dyscalculia Support System
# Model Evaluation Script
# ==========================================

import pandas as pd
import pickle

from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report
)


# -----------------------------
# Load dataset
# -----------------------------

data = pd.read_csv("cleaned_learner_data.csv")


# -----------------------------
# Keep Dyscalculia learners only
# -----------------------------

data = data[
    data["neurodivergence_type"] == "Dyscalculia"
].copy()


# -----------------------------
# Remove missing values
# -----------------------------

columns_needed = [

    "age_group",
    "education_level",
    "primary_challenge",
    "prior_elearning_experience",
    "font_type",
    "font_size_pt",
    "color_theme",
    "layout_mode",
    "content_format"

]

data = data.dropna(
    subset=columns_needed
)


# -----------------------------
# Load encoders
# -----------------------------

with open(
    "models/feature_encoders.pkl",
    "rb"
) as file:

    feature_encoders = pickle.load(file)


with open(
    "models/target_encoders.pkl",
    "rb"
) as file:

    target_encoders = pickle.load(file)



# -----------------------------
# Encode input features
# -----------------------------

features = [

    "age_group",
    "education_level",
    "primary_challenge",
    "prior_elearning_experience"

]


encoded_data = data.copy()


for feature in features:

    encoded_data[feature] = feature_encoders[feature].transform(
        encoded_data[feature].astype(str)
    )


X = encoded_data[features]


# -----------------------------
# Split evaluation data
# -----------------------------

X_train, X_test = train_test_split(

    X,

    test_size=0.2,

    random_state=42

)



# -----------------------------
# Evaluate each model
# -----------------------------

models = {

    "Content Model":
    ("models/content_model.pkl", "content_format"),

    "Font Model":
    ("models/font_model.pkl", "font_type"),

    "Theme Model":
    ("models/theme_model.pkl", "color_theme"),

    "Layout Model":
    ("models/layout_model.pkl", "layout_mode"),

    "Font Size Model":
    ("models/fontsize_model.pkl", "font_size_pt")

}



results = []


for name, (model_file, target) in models.items():


    # Load model

    with open(
        model_file,
        "rb"
    ) as file:

        model = pickle.load(file)



    # Encode target

    y = target_encoders[target].transform(
        encoded_data[target].astype(str)
    )


    _, y_test = train_test_split(

        y,

        test_size=0.2,

        random_state=42

    )


    predictions = model.predict(
        X_test
    )


    accuracy = accuracy_score(
        y_test,
        predictions
    )


    precision = precision_score(
        y_test,
        predictions,
        average="weighted",
        zero_division=0
    )


    recall = recall_score(
        y_test,
        predictions,
        average="weighted",
        zero_division=0
    )


    f1 = f1_score(
        y_test,
        predictions,
        average="weighted",
        zero_division=0
    )


    results.append({

        "Model": name,

        "Accuracy": round(accuracy*100,2),

        "Precision": round(precision*100,2),

        "Recall": round(recall*100,2),

        "F1 Score": round(f1*100,2)

    })


# -----------------------------
# Display results
# -----------------------------

results = pd.DataFrame(results)


print("\n==============================")
print("MODEL EVALUATION RESULTS")
print("==============================\n")


print(results)