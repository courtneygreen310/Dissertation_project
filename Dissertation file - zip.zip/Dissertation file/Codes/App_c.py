import streamlit as st
import pandas as pd
import pickle

# ==========================================
# Streamlit Page Setup
# ==========================================

st.set_page_config(
    page_title="AI Dyscalculia Support System"
)

st.title("AI Dyscalculia Support System")
st.write(
    "Enter learner information to receive personalised recommendations."
)

# ==========================================
# Load Trained Models
# ==========================================

with open("models/content_model.pkl", "rb") as file:
    content_model = pickle.load(file)

with open("models/font_model.pkl", "rb") as file:
    font_model = pickle.load(file)

with open("models/theme_model.pkl", "rb") as file:
    theme_model = pickle.load(file)

with open("models/layout_model.pkl", "rb") as file:
    layout_model = pickle.load(file)

with open("models/fontsize_model.pkl", "rb") as file:
    fontsize_model = pickle.load(file)

# ==========================================
# Load Encoders
# ==========================================

with open("models/feature_encoders.pkl", "rb") as file:
    feature_encoders = pickle.load(file)

with open("models/target_encoders.pkl", "rb") as file:
    target_encoders = pickle.load(file)

# ==========================================
# Store Recommendations
# ==========================================

if "recommendations_generated" not in st.session_state:
    st.session_state.recommendations_generated = False

if "content" not in st.session_state:
    st.session_state.content = None

if "font" not in st.session_state:
    st.session_state.font = None

if "theme" not in st.session_state:
    st.session_state.theme = None

if "layout" not in st.session_state:
    st.session_state.layout = None

if "fontsize" not in st.session_state:
    st.session_state.fontsize = None

# ==========================================
# User Inputs
# ==========================================

age = st.selectbox(
    "Age Group",
    feature_encoders["age_group"].classes_
)

education = st.selectbox(
    "Education Level",
    feature_encoders["education_level"].classes_
)

challenge = st.selectbox(
    "Primary Challenge",
    feature_encoders["primary_challenge"].classes_
)

experience = st.selectbox(
    "Prior E-learning Experience",
    feature_encoders[
        "prior_elearning_experience"
    ].classes_
)

# ==========================================
# Generate Recommendations
# ==========================================

if st.button("Generate Recommendations"):

    # Encode user input
    input_data = pd.DataFrame(
        {
            "age_group": [
                feature_encoders["age_group"].transform(
                    [age]
                )[0]
            ],

            "education_level": [
                feature_encoders["education_level"].transform(
                    [education]
                )[0]
            ],

            "primary_challenge": [
                feature_encoders["primary_challenge"].transform(
                    [challenge]
                )[0]
            ],

            "prior_elearning_experience": [
                feature_encoders[
                    "prior_elearning_experience"
                ].transform([experience])[0]
            ]
        }
    )

    # Make predictions
    content_prediction = content_model.predict(input_data)
    font_prediction = font_model.predict(input_data)
    theme_prediction = theme_model.predict(input_data)
    layout_prediction = layout_model.predict(input_data)
    fontsize_prediction = fontsize_model.predict(input_data)

    # Convert predictions back to readable values
    st.session_state.content = target_encoders[
        "content_format"
    ].inverse_transform(content_prediction)[0]

    st.session_state.font = target_encoders[
        "font_type"
    ].inverse_transform(font_prediction)[0]

    st.session_state.theme = target_encoders[
        "color_theme"
    ].inverse_transform(theme_prediction)[0]

    st.session_state.layout = target_encoders[
        "layout_mode"
    ].inverse_transform(layout_prediction)[0]

    st.session_state.fontsize = target_encoders[
        "font_size_pt"
    ].inverse_transform(fontsize_prediction)[0]

    st.session_state.recommendations_generated = True

    st.rerun()

# ==========================================
# Apply Recommendations to the Interface
# ==========================================

if st.session_state.recommendations_generated:

    content = str(st.session_state.content)
    font = str(st.session_state.font)
    theme = str(st.session_state.theme)
    layout = str(st.session_state.layout)

    try:
        fontsize = int(float(st.session_state.fontsize))
    except (ValueError, TypeError):
        fontsize = 16

    # Apply recommended font
    if font == "Dyslexia-Friendly":
        css_font = "Verdana, Arial, sans-serif"
    else:
        css_font = "Arial, Helvetica, sans-serif"

    # Apply recommended colour theme
    if theme == "High-Contrast":

        background_colour = "#000000"
        text_colour = "#FFFFFF"
        card_colour = "#000000"
        border_colour = "#FFFF00"
        button_colour = "#FFFF00"
        button_text_colour = "#000000"

    elif theme == "Low-Stimulation Pastel":

        background_colour = "#F3F0E8"
        text_colour = "#26332B"
        card_colour = "#E4EDE4"
        border_colour = "#9EAD9F"
        button_colour = "#718C78"
        button_text_colour = "#FFFFFF"

    elif theme == "Dark Mode":

        background_colour = "#181818"
        text_colour = "#FFFFFF"
        card_colour = "#242424"
        border_colour = "#666666"
        button_colour = "#555555"
        button_text_colour = "#FFFFFF"

    else:

        background_colour = "#FFFFFF"
        text_colour = "#222222"
        card_colour = "#F4F6F8"
        border_colour = "#CCCCCC"
        button_colour = "#0068C9"
        button_text_colour = "#FFFFFF"

    # Apply recommended layout
    if layout == "Distraction-Free":

        page_width = "600px"
        card_padding = "40px"
        text_alignment = "center"

    elif layout == "Simplified":

        page_width = "750px"
        card_padding = "30px"
        text_alignment = "left"

    else:

        page_width = "900px"
        card_padding = "20px"
        text_alignment = "left"

    # Apply CSS styling
    st.markdown(
        f"""
        <style>

        .stApp {{
            background-color: {background_colour};
            color: {text_colour};
        }}

        .block-container {{
            max-width: {page_width};
        }}

        .stApp,
        .stApp p,
        .stApp label,
        .stApp span,
        .stApp h1,
        .stApp h2,
        .stApp h3 {{
            font-family: {css_font};
            color: {text_colour};
        }}

        .stApp p,
        .stApp label {{
            font-size: {fontsize}px;
        }}

        input {{
            font-family: {css_font} !important;
            font-size: {fontsize}px !important;
        }}

        .stButton button {{
            background-color: {button_colour};
            color: {button_text_colour};
            font-family: {css_font};
            font-size: {fontsize}px;
            border: 2px solid {border_colour};
        }}

        .adaptive-content {{
            background-color: {card_colour};
            color: {text_colour};
            border: 2px solid {border_colour};
            border-radius: 12px;
            padding: {card_padding};
            margin-top: 20px;
            text-align: {text_alignment};
            font-family: {css_font};
            font-size: {fontsize}px;
        }}

        .adaptive-content h2,
        .adaptive-content p,
        .adaptive-content strong {{
            color: {text_colour};
            font-family: {css_font};
        }}

        </style>
        """,
        unsafe_allow_html=True
    )

    # Display adapted interface
    st.success("Personalised Recommendations Generated")

    
    st.subheader("Adaptations Applied")

    st.info(f"Content format changed to: {content}")

    st.info(f"Font changed to: {font}")

    st.info(f"Font size changed to: {fontsize} pt")

    st.info(f"Colour theme changed to: {theme}")

    st.info(f"Layout changed to: {layout}")